In this # React User App

This is a simple React application for managing user data. It allows users to view, add, update, and delete data stored in the local database.



- View a list of users with their details.
- Add new users to the database.
- Update existing user data.
- Delete users from the database.



- Node.js and npm installed on your machine.
After running this app you will redirct to the login page then after sucessfull login you will redirct to the home page.
Home page will contain a login button and product button.
login button will redirct back to login page. And product button redirct to the next page where you have data sows in table that are fatched from the api and you can perform crud opration on that data. and user id will genrate through a random function that will genrate a unique id for each data.

